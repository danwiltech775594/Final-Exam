package com.example.FinalExam.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.FinalExam.model.Person;

public interface PersonRepository extends CrudRepository<Person, Integer>{

}
