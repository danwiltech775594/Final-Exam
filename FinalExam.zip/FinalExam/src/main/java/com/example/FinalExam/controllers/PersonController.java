package com.example.FinalExam.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.FinalExam.model.Person;
import com.example.FinalExam.services.PersonService;

@RestController
@CrossOrigin("*")
public class PersonController {
	@Autowired
	PersonService personService;
	
	//Create
	@PostMapping("api/person")
	public Person addPerson(@RequestBody Person person) {
		return personService.addPerson(person);
	}
		
	//Read All
	@GetMapping("api/person")
	public ArrayList<Person> getAllPeople(){
		return personService.getAllPeople();
	}
}
