package com.example.FinalExam.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "Person")
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	Integer id;
	String name;
	Integer age;
	String product_manufacturer;
	String vaccine_dose;
	String date;
	
	public Person(Integer Id, String Name, Integer Age, String Product_manufacturer, String Vaccine_dose, String Date) {
	
		this.id = Id;
		this.name = Name;
		this.age = Age;
		this.product_manufacturer = Product_manufacturer;
		this.vaccine_dose = Vaccine_dose;
		this.date = Date;		
	}
	
	public Person() {	
	}
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getProduct_manufacturer() {
		return product_manufacturer;
	}
	public void setProduct_manufacturer(String product_manufacturer) {
		this.product_manufacturer = product_manufacturer;
	}
	public String getVaccine_dose() {
		return vaccine_dose;
	}
	public void setVaccine_dose(String vaccine_dose) {
		this.vaccine_dose = vaccine_dose;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
}
