package com.example.FinalExam.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.FinalExam.model.Person;
import com.example.FinalExam.repositories.PersonRepository;


@Service
public class PersonService {
	@Autowired
	PersonRepository PRepo;
	
	//Create Person 
	public Person addPerson(Person person) {
		return PRepo.save(person);
	}
	
	public ArrayList<Person> getAllPeople(){
		return (ArrayList<Person>) PRepo.findAll();
	}
	
}
